package com.todo.demo.domain;

import com.todo.demo.repository.SkillRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
@Data
@Entity
@Table(name="taskSkills")
@AllArgsConstructor
@NoArgsConstructor
public class TaskSkill {
    private Tasks tasks;
    private SkillRepository skillRepository;

    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "task_seq")
    @SequenceGenerator(allocationSize = 1,initialValue = 1,name="task_seq", schema = "public")
    @Column(name="id", nullable=false, unique=true)
    private Long id;

    @ManyToOne(cascade = {javax.persistence.CascadeType.MERGE},fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id")
    private Tasks task;

    @ManyToOne(cascade = {javax.persistence.CascadeType.MERGE},fetch = FetchType.LAZY)
    @JoinColumn(name="skill_id")
    private Skill skill;
}
