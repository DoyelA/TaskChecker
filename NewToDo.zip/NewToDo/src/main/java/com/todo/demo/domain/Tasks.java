package com.todo.demo.domain;

import lombok.Data;

import javax.persistence.*;

@Data
@Table(name="Tasks", schema="public")
@Entity

public class Tasks{
    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator = "task_seq")
    @SequenceGenerator(allocationSize = 1,initialValue = 1,name="task_seq", schema = "public")
    @Column(name="task_id", nullable=false, unique=true)
    private Long id;

    @Column(name="task_description", nullable = false, length=200)
    private String description;
    public Tasks(){
    }

}
