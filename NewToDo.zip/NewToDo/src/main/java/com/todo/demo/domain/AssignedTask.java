//package com.todo.demo.domain;
//
//public class AssignedTask {
//
//}
