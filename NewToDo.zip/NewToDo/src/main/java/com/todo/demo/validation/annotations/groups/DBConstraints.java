package com.todo.demo.validation.annotations.groups;

public interface DBConstraints {
}
